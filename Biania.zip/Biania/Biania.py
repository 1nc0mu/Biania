import discord
from discord.ext import commands
from colorama import init, Fore
import warnings
import asyncio
import logging

# Suppress the deprecation warning
warnings.filterwarnings("ignore", category=DeprecationWarning)

# Suppress Discord's logging output (INFO and below) by targeting specific loggers
logging.basicConfig(level=logging.WARNING)

# Suppress specific discord library logs
logging.getLogger('discord.client').setLevel(logging.WARNING)  # Suppress discord.client logs
logging.getLogger('discord.gateway').setLevel(logging.WARNING)  # Suppress discord.gateway logs

# Initialize colorama
init(autoreset=True)

# ASCII art for the menu header
ascii_art = """
oooooooooo.   o8o                         o8o            
`888'   `Y8b  `"'                         `"'            
 888     888 oooo   .oooo.   ooo. .oo.   oooo   .oooo.   
 888oooo888' `888  `P  )88b  `888P"Y88b  `888  `P  )88b  
 888    `88b  888   .oP"888   888   888   888   .oP"888  
 888    .88P  888  d8(  888   888   888   888  d8(  888  
o888bood8P'  o888o `Y888""8o o888o o888o o888o `Y888""8o 
"""

# Function to print colored ASCII art
def print_colored_ascii_art():
    print(Fore.MAGENTA + ascii_art)

# Setup bot
TOKEN = "MTMxMDY4MjQxMjI1Mzk3MDU0NA.GWV0sp.92Ie-ZkX0nzu2BTdXFrRY8ki4bcMFdXyhbcTsg"  # Replace with your bot's token
intents = discord.Intents.default()
intents.guilds = True
intents.messages = True
intents.message_content = True
bot = commands.Bot(command_prefix="$", intents=intents)

# Event fired when bot is ready and connected to the server
@bot.event
async def on_ready():
    """When bot is connected to the server."""
    print(f"Logged in as {bot.user} ({bot.user.id})")

    # Check if bot is connected to any guilds
    if not bot.guilds:
        print("❌ The bot is not connected to any guilds. Please invite it to a server.")
    else:
        print("✅ The bot is connected to guilds.")
        
    # Trigger the menu in the terminal after bot is ready
    await show_menu()

async def show_menu():
    """Function to display the menu and process user input in the terminal."""
    while True:
        print("=" * 70)
        print_colored_ascii_art()  # Print ASCII Art
        print("=" * 70)
        
        # Show the menu with updated options
        print("Choose an option (1/2/3/4):")
        print("1. Backup Channels")
        print("2. Delete All Channels")
        print("3. Delete Message")
        print("4. Exit")
        print("=" * 70)

        # Call the async input function
        choice = await async_input("Enter your choice: ")

        # Handle user input
        if choice == "1":
            print("You selected 'Backup Channels'. Executing backup...")
            await backup_channels()
        elif choice == "2":
            print("You selected 'Delete All Channels'. Deleting all channels...")
            await delete_all_channels()
        elif choice == "3":
            print("You selected 'Delete Message'. Deleting messages...")
            await delete_message()
        elif choice == "4":
            print("You selected 'Exit'. Exiting the program...")
            break
        else:
            print("Invalid option! Please choose a valid option (1/2/3/4).")

async def async_input(prompt: str) -> str:
    """Non-blocking input function."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, input, prompt)

async def backup_channels():
    """Backup channels and categories from the source guild to the target guild."""
    source_guild_id = int(input("Enter the source guild ID (server to copy channels from): "))
    target_guild_id = int(input("Enter the target guild ID (server to paste channels into): "))

    source_guild = bot.get_guild(source_guild_id)
    target_guild = bot.get_guild(target_guild_id)

    if not source_guild or not target_guild:
        print("Invalid guild IDs. Please make sure the bot is in both guilds.")
        return

    print(f"Backing up channels from {source_guild.name}...")

    # Backup categories and channels data
    backup_data = {'categories': {}, 'channels': []}

    # Backup categories and text channels
    for category in source_guild.categories:
        backup_data['categories'][category.id] = {
            'name': category.name,
            'channels': [channel.id for channel in category.text_channels]
        }

        # Backup text channels within the category
        for channel in category.text_channels:
            backup_data['channels'].append({
                'id': channel.id,
                'name': channel.name,
                'category_id': category.id,
                'type': 'text'
            })

    # Backup voice channels
    for channel in source_guild.voice_channels:
        backup_data['channels'].append({
            'id': channel.id,
            'name': channel.name,
            'category_id': None,  # No category for voice channels
            'type': 'voice'
        })

    # Paste channels into the target guild
    print(f"Pasting channels into {target_guild.name}...")

    # Create categories in target guild
    category_map = {}  # Keep track of created categories to avoid duplicates
    for category_id, category_info in backup_data['categories'].items():
        # Check if category already exists in target guild
        existing_category = discord.utils.get(target_guild.categories, name=category_info['name'])
        if existing_category:
            category_map[category_id] = existing_category.id
        else:
            # Create category in target guild if it doesn't exist
            category = await target_guild.create_category(category_info['name'])
            category_map[category_id] = category.id  # Map source category ID to target category ID

    # Create text and voice channels in the target guild
    for channel_data in backup_data['channels']:
        # Check if channel already exists to avoid duplication
        existing_channel = discord.utils.get(target_guild.text_channels, name=channel_data['name'], category=target_guild.get_channel(category_map.get(channel_data['category_id'])))

        if not existing_channel:
            if channel_data['type'] == 'text':
                # Create text channels in the respective category (if category exists)
                category = target_guild.get_channel(category_map.get(channel_data['category_id']))
                await target_guild.create_text_channel(channel_data['name'], category=category)
            elif channel_data['type'] == 'voice':
                # Create voice channels without a category
                await target_guild.create_voice_channel(channel_data['name'])
        else:
            print(f"Channel '{channel_data['name']}' already exists in {target_guild.name}.")

    print(f"Backup and pasting completed for {target_guild.name}.")
    print("=" * 70)

async def delete_all_channels():
    """Deletes all channels and categories in a specified guild."""
    guild_id = int(input("Enter the guild ID to delete channels and categories: "))
    guild = bot.get_guild(guild_id)

    if not guild:
        print("Invalid guild ID. Please make sure the bot is in this guild.")
        return

    print(f"Deleting all channels and categories in {guild.name}...")

    # Delete channels
    for channel in guild.text_channels:
        await channel.delete()
        print(f"Deleted channel: {channel.name}")

    for channel in guild.voice_channels:
        await channel.delete()
        print(f"Deleted voice channel: {channel.name}")

    # Optionally, you could delete categories if needed
    for category in guild.categories:
        await category.delete()
        print(f"Deleted category: {category.name}")

    print(f"All channels and categories have been deleted in {guild.name}.")
    print("=" * 70)

async def delete_message():
    """Delete messages containing a specified word/phrase across all channels in a guild."""
    word_to_delete = input("Enter the word/phrase to delete messages containing it: ")
    guild_id = int(input("Enter the guild ID to delete messages from: "))
    guild = bot.get_guild(guild_id)

    if not guild:
        print("Invalid guild ID. Please make sure the bot is in this guild.")
        return

    print(f"Deleting messages containing '{word_to_delete}' in all channels of {guild.name}...")

    # Loop through all text channels in the guild
    for channel in guild.text_channels:
        print(Fore.LIGHTBLACK_EX + f"Checking channel: {channel.name}")  # Grey message for checking
        # Fetch messages and delete those that match the word/phrase
        async for message in channel.history(limit=100):
            if word_to_delete.lower() in message.content.lower():
                await message.delete()
                print(Fore.GREEN + f"Deleted message: {message.content}")  # Green message for deleted

    print("Message deletion completed.")
    print("=" * 70)

# Run the bot
bot.run(TOKEN)

































































































